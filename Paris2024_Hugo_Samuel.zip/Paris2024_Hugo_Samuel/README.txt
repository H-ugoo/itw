adicionámos search bar e filtros nos atletas.
adicionámos search bar nos coaches e nas modalities.
adicionámos imagem para quando os atletas e coaches não carregam.
adicionámos opção 'Sports' na navbar que possui as paginas para os desportos: Athletics, Basketball, Canoe Sprint, Cycling Track, Football e Swimming. 
adicionámos as respetivas páginas de detalhes das opções.
adicionámos dentro da opção 'More' uma página 'Nocs' e a suas respetiva página de detalhes.
adicionámos informações sobre as condições atmosféricas da cidade dentro da 'Tourch Route'.
adicionámos um gráfico para ilustrar os dados das medalhas.
retificámos alguns aspetos estéticos do site, principalmente na homepage e nos favoritos.