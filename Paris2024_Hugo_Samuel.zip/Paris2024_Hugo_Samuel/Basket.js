var vm = function () {
    console.log('ViewModel started...');
    var self = this;
    self.baseUri = ko.observable('http://192.168.160.58/Paris2024/API/Basketballs/');
    self.displayName = 'Basket - Match List';
    self.error = ko.observable('');
    var NomeEvents = [];
    var NomeStages = [];
    self.currentPage = ko.observable(1);
    self.itemsPerPage = 20;
    self.itemInicialOnPage = ko.observable(1);
    self.itemFinalOnPage = ko.observable(20);
    var StagesDiferentesSet = {};
    self.selectedEventId = ko.observable('');
    self.selectedStageId = ko.observable('');
    self.selectedEventName = ko.observable('');
    self.selectedStageName = ko.observable('');
    self.tempGrupos = ko.observable([]);
    self.Matches = ko.observableArray([]);
    self.visibleMatches = ko.observableArray([]);
    self.tempEvents = ko.observableArray([]);
    self.tempStages = ko.observableArray([]);
    self.eventIds = ko.observableArray([]);
    self.stageIds = ko.observableArray([]);
    self.totalPages = ko.computed(() => Math.ceil(self.Matches().length / self.itemsPerPage));
    self.pages = ko.computed(() => Array.from({ length: self.totalPages() }, (_, i) => i + 1));

    self.updateVisibleMatches = function () {
        const startIndex = (self.currentPage() - 1) * self.itemsPerPage;
        const endIndex = startIndex + self.itemsPerPage;
        self.visibleMatches(self.Matches().slice(startIndex, endIndex));
        self.itemInicialOnPage(startIndex + 1);
        self.itemFinalOnPage(Math.min(endIndex, self.Matches().length));
    };

    self.goToPage = function (page) {
        if (page >= 1 && page <= self.totalPages()) {
            self.currentPage(page);
            self.updateVisibleMatches();
        }
    };

    self.prevPage = function () {
        if (self.currentPage() > 1) {
            self.goToPage(self.currentPage() - 1);
        }
    };

    self.nextPage = function () {
        if (self.currentPage() < self.totalPages()) {
            self.goToPage(self.currentPage() + 1);
        }
    };

    self.loadEventIds = function () {
        const eventsUri = 'http://192.168.160.58/Paris2024/API/Basketballs/Events';
        ajaxHelper(eventsUri, 'GET').done(function (data) {
            console.log('Events received:', data);
            if (Array.isArray(data)) {
                for (let i = 0; i < data.length; i++) {
                    if (!NomeEvents.includes(data[i].EventName)) {
                        NomeEvents.push(data[i].EventName);
                    }
                }
                self.eventIds(NomeEvents);
                self.tempEvents(data);
            } else {
                console.log('Error: Data is not in the expected format', data);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log('Error loading events:', textStatus, errorThrown);
        });
    };

    self.loadStageIds = function () {
        const stageUri = 'http://192.168.160.58/Paris2024/api/Basketballs?EventId=' + self.selectedEventId() + '&StageId=';
        ajaxHelper(stageUri, 'GET').done(function (data) {
            console.log('Stages received:', data);
            for (let i = 0; i < data.length; i++) {
                if (!NomeStages.includes(data[i].Name)) {
                    NomeStages.push(data[i].Name);
                }
            }

            for (let j = 0; j < data.length; j++) {
                const item = data[j];
                const { Name, StageId } = item;

                if (!StagesDiferentesSet[Name]) {
                    StagesDiferentesSet[Name] = [];
                }

                if (!StagesDiferentesSet[Name].includes(StageId)) {
                    StagesDiferentesSet[Name].push(StageId);
                }
            }

            console.log('Unique Stages:', StagesDiferentesSet);
            self.stageIds(NomeStages);
            self.tempStages(data);
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log('Error loading stages:', textStatus, errorThrown);
        });
    };

    self.loadMatches = function () {
        console.log('CALL: getMatches...');
        function getEventIdByName(eventArray, eventName) {
            const event = eventArray.find(e => e.EventName === eventName);
            if (!event) {
                console.log('Event not found:', eventName);
                return 'Event not found.';
            }
            return event.EventId;
        }
        self.selectedEventId(getEventIdByName(self.tempEvents(), self.selectedEventName()));
        console.log('Selected Event ID:', self.selectedEventId());

        function getStageIdByName(array, name) {
            const stage = array.find(item => item.Name === name);

            if (!stage) {
                console.log('Stage not found:', name);
                return 'Stage not found.';
            }

            return stage.StageId;
        }

        NomeStages = [];
        self.loadStageIds();

        console.log('LOADSTAGEIDS =', self.tempStages());
        console.log(`Fetching matches for Name: ${self.selectedStageName()}`);

        const stageIds = StagesDiferentesSet[self.selectedStageName()];
        if (!stageIds || stageIds.length === 0) {
            console.log('No StageId found for this Name.');
            return;
        }
        console.log('stageIds =', stageIds);

        self.selectedStageId(getStageIdByName(self.tempStages(), self.selectedStageName()));
        console.log('StageID =', self.selectedStageId());

        let allMatches = [];
        showLoading();

        const composedBaseUri = `http://192.168.160.58/Paris2024/API/Basketballs?EventId=${encodeURIComponent(self.selectedEventId())}`;

        function loadMatchesForStage(stageIds, index = 0) {
            if (index >= stageIds.length) {
                console.log('ALL MATCHES LOADED:', allMatches);
                self.Matches(allMatches);
                self.currentPage(1);
                self.updateVisibleMatches();
                hideLoading();
                return;
            }

            const stageId = stageIds[index];
            const uri = `${composedBaseUri}&StageId=${stageId}`;
            
            ajaxHelper(uri, 'GET')
                .done(function (data) {
                    data.forEach(match => {
                        const exists = allMatches.some(existingMatch => existingMatch.Id === match.Id);
                        if (!exists) {
                            allMatches.push(match);
                        }
                    });
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    console.error(`Error loading matches for StageId ${stageId}:`, textStatus, errorThrown);
                })
                .always(function () {
                    loadMatchesForStage(stageIds, index + 1);
                });
        }

        loadMatchesForStage(stageIds);
    };

    self.initialize = function () {
        self.loadEventIds();
        self.loadStageIds();
    };

    self.initialize();
};

ko.applyBindings(new vm());

function showLoading() {
    const loadingModal = document.getElementById('myModal');
    loadingModal.style.display = 'block';
    document.body.style.cursor = 'wait';
}

function hideLoading() {
    const loadingModal = document.getElementById('myModal');
    loadingModal.style.display = 'none';
    document.body.style.cursor = 'default';
}

function ajaxHelper(uri, method, data) {
    return $.ajax({
        type: method,
        url: uri,
        dataType: 'json',
        contentType: 'application/json',
        data: data ? JSON.stringify(data) : null,
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(`AJAX Call [${uri}] Fail...`);
            hideLoading();
        }
    });
}

$(document).ready(function () {
    console.log('Document ready!');
});

$(document).ajaxComplete(function () {
    $('#myModal').modal('hide');
});
