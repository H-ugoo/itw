var vm = function () {
    console.log('ViewModel initiated...');
    var self = this;
    self.baseUri = ko.observable('http://192.168.160.58/Paris2024/API/CountryMedals');
    self.displayName = 'Paris2024 Medals List';
    self.error = ko.observable('');
    self.Medals = ko.observableArray([]); 
    self.favourites = ko.observableArray([]); 
    self.loadMedals = function () {
        console.log('API...');
        ajaxHelper(self.baseUri(), 'GET').done(function (data) {
            console.log('Dados recebidos:', data);
            self.Medals(data);
            var countryLabels = data.map(function (item) {
                return item.CountryName;
            });
    
            var goldMedals = data.map(function (item) {
                return item.GoldMedal;
            });
    
            var silverMedals = data.map(function (item) {
                return item.SilverMedal;
            });
    
            var bronzeMedals = data.map(function (item) {
                return item.BronzeMedal;
            });
    
            var ctx = document.getElementById('medalsChart').getContext('2d');
            var medalsChart = new Chart(ctx, {
                type: 'bar', 
                data: {
                    labels: countryLabels, 
                    datasets: [{
                        label: 'Gold Medals',
                        data: goldMedals,
                        backgroundColor: 'gold',
                        borderColor: 'gold',
                        borderWidth: 1
                    },
                    {
                        label: 'Silver Medals',
                        data: silverMedals,
                        backgroundColor: 'silver',
                        borderColor: 'silver',
                        borderWidth: 1
                    },
                    {
                        label: 'Bronze Medals',
                        data: bronzeMedals,
                        backgroundColor: '#cd7f32',
                        borderColor: '#cd7f32',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: {
                            beginAtZero: true
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    return tooltipItem.dataset.label + ': ' + tooltipItem.raw;
                                }
                            }
                        }
                    }
                }
            });
        });
    };
    

    function ajaxHelper(uri, method, data) {
        self.error(''); 
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null,
            error: function (jqXHR, textStatus, errorThrown) {
                console.error(`AJAX Call[${uri}] Falhou...`);
                self.error(errorThrown);
            }
        });
    }

    self.loadMedals(); 
};

$(document).ready(function () {
    console.log(' bindings...');
    ko.applyBindings(new vm());
});
