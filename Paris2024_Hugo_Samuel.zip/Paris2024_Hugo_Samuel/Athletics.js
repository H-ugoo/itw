var vm = function () {
    console.log('ViewModel initialized...');
    var self = this;
    self.baseUri = ko.observable('http://192.168.160.58/Paris2024/API/Athletics'); 
    self.displayName = 'Athletics - Event List';
    self.error = ko.observable('');
    self.Matches = ko.observableArray([]);
    self.visibleMatches = ko.observableArray([]);
    self.currentPage = ko.observable(1);
    self.itemsPerPage = 20;
    self.itemInicialOnPage = ko.observable(1);
    self.itemFinalOnPage = ko.observable(20);
    var eventNames = [];
    var stageNames = [];
    self.tempEvents = ko.observableArray([]);
    self.tempStages = ko.observableArray([]);
    self.selectedEventId = ko.observable('');
    self.selectedStageId = ko.observable('');
    self.selectedEventName = ko.observable('');
    self.selectedStageName = ko.observable('');
    self.eventIds = ko.observableArray([]);
    self.stageIds = ko.observableArray([]);
    self.totalPages = ko.computed(() => Math.ceil(self.Matches().length / self.itemsPerPage));
    self.pages = ko.computed(() => Array.from({ length: self.totalPages() }, (_, i) => i + 1));
    self.updateVisibleMatches = function () {
        const startIndex = (self.currentPage() - 1) * self.itemsPerPage;
        const endIndex = startIndex + self.itemsPerPage;
        self.visibleMatches(self.Matches().slice(startIndex, endIndex));
        self.itemInicialOnPage(startIndex + 1);
        self.itemFinalOnPage(Math.min(endIndex, self.Matches().length));
    };

    self.goToPage = function (page) {
        if (page >= 1 && page <= self.totalPages()) {
            self.currentPage(page);
            self.updateVisibleMatches();
        }
    };

    self.prevPage = function () {
        if (self.currentPage() > 1) {
            self.goToPage(self.currentPage() - 1);
        }
    };

    self.nextPage = function () {
        if (self.currentPage() < self.totalPages()) {
            self.goToPage(self.currentPage() + 1);
        }
    };

    self.loadMatches = function () {
        console.log('CALL: getMatches...');
        
        function getEventIdByName(eventArray, eventName) {
            const event = eventArray.find(e => e.EventName === eventName);
            if (!event) {
                console.log("Event not found:", eventName);
                return "Event not found.";
            }
            return event.EventId;
        }

        function getStageIdByName(array, name) {
            const stage = array.find(item => item.Name === name);
            if (!stage) {
                console.log("Stage not found:", name);
                return "Stage not found.";
            }
            return stage.StageId;
        }

        self.selectedEventId(getEventIdByName(self.tempEvents(), self.selectedEventName()));
        console.log("Selected Event ID:", self.selectedEventId());
        stageNames = [];
        self.loadStageIds();
        console.log("LOADSTAGEIDS =", self.tempStages());
        console.log("Selected Stage Name:", self.selectedStageName());
        self.selectedStageId(getStageIdByName(self.tempStages(), self.selectedStageName()));
        console.log("StageID =", self.selectedStageId());
        const composedUri = self.baseUri() + '?EventId=' + self.selectedEventId() + '&StageId=' + self.selectedStageId();
        console.log('Fetching matches from:', composedUri);
        showLoading();
        ajaxHelper(composedUri, 'GET').done(function (data) {
            console.log('Matches:', data);
            hideLoading();
            self.Matches(data);
            self.currentPage(1);
            self.updateVisibleMatches();
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("Error loading matches:", textStatus, errorThrown);
            hideLoading();
        });
    };

    self.loadEventIds = function () {
        const eventsUri = 'http://192.168.160.58/Paris2024/API/Athletics/Events';
        ajaxHelper(eventsUri, 'GET').done(function (data) {
            showLoading();
            console.log('Received events:', data);

            if (Array.isArray(data)) {
                for (let i = 0; i < data.length; i++) {
                    if (!eventNames.includes(data[i].EventName)) {
                        eventNames.push(data[i].EventName);
                    }
                }
                hideLoading();
                self.eventIds(eventNames);
                self.tempEvents(data);
            } else {
                console.log('Error: Data is not in the expected format', data);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("Error loading events:", textStatus, errorThrown);
        });
    };

    self.loadStageIds = function () {
        const stageUri = 'http://192.168.160.58/Paris2024/API/Athletics?EventId=' + self.selectedEventId() + '&StageId=';
        ajaxHelper(stageUri, 'GET').done(function (data) {
            console.log('Received stages:', data);
            for (let i = 0; i < data.length; i++) {
                if (!stageNames.includes(data[i].Name)) {
                    stageNames.push(data[i].Name);
                }
            }
            self.stageIds(stageNames);
            self.tempStages(data);
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("Error loading stages:", textStatus, errorThrown);
        });
    };

    self.initialize = function () {
        self.loadEventIds();
        self.loadStageIds();
    };

    self.initialize();
};

function showLoading() {
    const loadingModal = document.getElementById('myModal');
    loadingModal.style.display = 'block';
    document.body.style.cursor = 'wait';
}

function hideLoading() {
    const loadingModal = document.getElementById('myModal');
    loadingModal.style.display = 'none';
    document.body.style.cursor = 'default';
}

function ajaxHelper(uri, method, data) {
    return $.ajax({
        type: method,
        url: uri,
        dataType: 'json',
        contentType: 'application/json',
        data: data ? JSON.stringify(data) : null,
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("AJAX Call[" + uri + "] Fail...");
            hideLoading();
        }
    });
}
    ko.applyBindings(new vm());

$(document).ready(function () {
    console.log("Document ready!");
});

$(document).ajaxComplete(function () {
    $("#myModal").modal('hide');
});
