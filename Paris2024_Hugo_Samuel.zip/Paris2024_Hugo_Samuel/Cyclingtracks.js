var vm = function () {
    console.log('ViewModel iniciado...');
    var self = this;
    self.baseUri = ko.observable('http://192.168.160.58/Paris2024/API/Cycling_Tracks'); 
    self.displayName = 'Cycling';
    self.error = ko.observable('');
    self.Matches = ko.observableArray([]);
    self.visibleMatches = ko.observableArray([]);
    self.currentPage = ko.observable(1);
    self.itemsPerPage = 20;
    self.itemInicialOnPage = ko.observable(1);
    self.itemFinalOnPage = ko.observable(20);
    var NomeEvents = [];
    var NomeStages = [];
    self.tempEvents = ko.observableArray([]);
    self.tempStages = ko.observableArray([]);
    self.selectedEventId = ko.observable('');
    self.selectedStageId = ko.observable('');
    self.selectedEventName = ko.observable('');
    self.selectedStageName = ko.observable('');
    self.eventIds = ko.observableArray([]);
    self.stageIds = ko.observableArray([]);
    self.totalPages = ko.computed(() => Math.ceil(self.Matches().length / self.itemsPerPage));
    self.pages = ko.computed(() => Array.from({ length: self.totalPages() }, (_, i) => i + 1));
    self.updateVisibleMatches = function () {
        const startIndex = (self.currentPage() - 1) * self.itemsPerPage;
        const endIndex = startIndex + self.itemsPerPage;
        self.visibleMatches(self.Matches().slice(startIndex, endIndex));
        self.itemInicialOnPage(startIndex + 1);
        self.itemFinalOnPage(Math.min(endIndex, self.Matches().length));
    };
    self.goToPage = function (page) {
        if (page >= 1 && page <= self.totalPages()) {
            self.currentPage(page);
            self.updateVisibleMatches();
        }
    };
    self.prevPage = function () {
        if (self.currentPage() > 1) {
            self.goToPage(self.currentPage() - 1);
        }
    };
    self.nextPage = function () {
        if (self.currentPage() < self.totalPages()) {
            self.goToPage(self.currentPage() + 1);
        }
    };

    self.loadMatches = function () {
        console.log('CALL: getMatches...');

        function getEventIdByName(eventArray, eventName) {
            const event = eventArray.find(e => e.EventName === eventName);
            if (!event) {
                console.log("Event 404", eventName);
                return "Event 404";
            }
            return event.EventId;
        }

        function getStageIdByName(array, name) {
            const stage = array.find(item => item.Name === name);
            if (!stage) {
                console.log("Stage 404:", name);
                return "Stage 404";
            }
            return stage.StageId;
        }

        self.selectedEventId(getEventIdByName(self.tempEvents(), self.selectedEventName()));
        console.log("Selected Event ID:", self.selectedEventId());
        NomeStages = [];
        self.loadStageIds();
        console.log("LOADSTAGEIDS =", self.tempStages());
        console.log("Selected Stage Name:", self.selectedStageName());
        self.selectedStageId(getStageIdByName(self.tempStages(), self.selectedStageName()));
        console.log("StageID =", self.selectedStageId());
        const composedUri = self.baseUri() + '?EventId=' + self.selectedEventId() + '&StageId=' + self.selectedStageId();
        showLoading();

        ajaxHelper(composedUri, 'GET').done(function (data) {
            console.log('MATCHES:', data);
            hideLoading();
            self.Matches(data);
            self.currentPage(1);
            self.updateVisibleMatches();
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("Error:", textStatus, errorThrown);
            hideLoading();
        });
    };
    self.loadEventIds = function () {
        const eventsUri = 'http://192.168.160.58/Paris2024/API/Cycling_Tracks/Events';

        ajaxHelper(eventsUri, 'GET').done(function (data) {
            showLoading();
            console.log('Events:', data);

            if (Array.isArray(data)) {
                data.forEach(event => {
                    if (!NomeEvents.includes(event.EventName)) NomeEvents.push(event.EventName);
                });

                hideLoading();
                self.eventIds(NomeEvents);
                self.tempEvents(data);
            } else {
                console.log('Error:', data);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("Error::", textStatus, errorThrown);
        });
    };

    self.loadStageIds = function () {
        const stageUri = `${self.baseUri()}?EventId=${self.selectedEventId()}&StageId=`;

        ajaxHelper(stageUri, 'GET').done(function (data) {
            console.log('Stages:', data);
            data.forEach(stage => {
                if (!NomeStages.includes(stage.Name)) NomeStages.push(stage.Name);
            });

            self.stageIds(NomeStages);
            self.tempStages(data);
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("Erroer:", textStatus, errorThrown);
        });
    };

    self.initialize = function () {
        self.loadEventIds();
        self.loadStageIds();
    };

    self.initialize();
};

ko.applyBindings(new vm());

function showLoading() {
    const loadingModal = document.getElementById('myModal');
    loadingModal.style.display = 'block';
    document.body.style.cursor = 'wait';
}

function hideLoading() {
    const loadingModal = document.getElementById('myModal');
    loadingModal.style.display = 'none';
    document.body.style.cursor = 'default';
}

function ajaxHelper(uri, method, data) {
    return $.ajax({
        type: method,
        url: uri,
        dataType: 'json',
        contentType: 'application/json',
        data: data ? JSON.stringify(data) : null,
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(`AJAX Call [${uri}] Fail...`);
            hideLoading();
        }
    });
}

$(document).ready(function () {
    console.log('Document ready!');
});

$(document).ajaxComplete(function () {
    $('#myModal').modal('hide');
});